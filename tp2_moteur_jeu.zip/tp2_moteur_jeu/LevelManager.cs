using Godot;
using System;

public partial class LevelManager : Node
{
    
}
